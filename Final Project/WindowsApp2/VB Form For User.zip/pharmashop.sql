-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2018 at 10:44 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmashop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `invoice_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `ordered_quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`invoice_id`, `product_id`, `ordered_quantity`) VALUES
(1, 1, 2),
(1, 6, 1),
(1, 9, 3),
(1, 12, 2),
(2, 2, 1),
(2, 4, 1),
(3, 13, 10);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(1, 'Medicine'),
(2, 'Food'),
(3, 'Drink'),
(4, 'Others');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `client_id` int(11) NOT NULL,
  `client_type` varchar(50) NOT NULL,
  `restriction_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `client_type`, `restriction_id`) VALUES
(1, 'Regular Customer', 1),
(2, 'Customer with Doctor Prescription', 2),
(3, 'Hospital Prescription', 3);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoice_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `shopkeeper_id` int(11) NOT NULL,
  `pharmasist_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoice_id`, `client_id`, `shopkeeper_id`, `pharmasist_id`) VALUES
(1, 1, 1, 1),
(2, 2, 2, 2),
(3, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pharmasist`
--

CREATE TABLE `pharmasist` (
  `pharmasist_id` int(11) NOT NULL,
  `pharmasist_name` varchar(50) NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmasist`
--

INSERT INTO `pharmasist` (`pharmasist_id`, `pharmasist_name`, `isactive`) VALUES
(1, 'Sam', 1),
(2, 'Adrian', 1),
(3, 'Eric', 1),
(4, 'Jean', 1),
(5, 'Mark', 1),
(6, 'Pierre', 1);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL,
  `subcategory_id` int(11) DEFAULT NULL,
  `restriction_id` int(11) DEFAULT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_description` varchar(200) NOT NULL,
  `product_price` int(11) DEFAULT NULL,
  `product_quantity` int(11) DEFAULT NULL,
  `isonmarket` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `subcategory_id`, `restriction_id`, `product_name`, `product_description`, `product_price`, `product_quantity`, `isonmarket`) VALUES
(1, 16, 1, 'Aqua 600ml', '', 5000, 200, 1),
(2, 10, 2, 'Fukricin 5%', '', 40000, 20, 1),
(3, 8, 3, 'Diamorphine 1kg', '', 400000, 4, 1),
(4, 10, 2, 'Iliadin 0,05%', '', 61000, 15, 1),
(5, 9, 1, 'Natra Bio', '', 8000, 50, 1),
(6, 9, 1, 'Nelco OBH', '', 47000, 20, 1),
(7, 11, 2, 'NonyX', '', 30000, 15, 1),
(8, 8, 3, 'Morphine 1kg', '', 700000, 2, 1),
(9, 12, 1, 'Xon-C', '', 6000, 20, 1),
(10, 14, 1, 'Pocari Sweat 600ml', '', 10000, 20, 1),
(11, 13, 1, 'Purple Corn 1kg', '', 70000, 10, 1),
(12, 15, 1, 'Chitato Barbeque 65g', '', 8000, 10, 1),
(13, 16, 1, 'Oasis 600ml', '', 4000, 50, 1);

-- --------------------------------------------------------

--
-- Table structure for table `restriction`
--

CREATE TABLE `restriction` (
  `restriction_id` int(11) NOT NULL,
  `restriction_level` int(11) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restriction`
--

INSERT INTO `restriction` (`restriction_id`, `restriction_level`, `description`) VALUES
(1, 1, 'Over-the-counter'),
(2, 2, 'Doctor Prescription (Regular)'),
(3, 3, 'Hospital Use / Special Prescription (Critical)');

-- --------------------------------------------------------

--
-- Table structure for table `shopkeeper`
--

CREATE TABLE `shopkeeper` (
  `shopkeeper_id` int(11) NOT NULL,
  `shopkeeper_name` varchar(50) NOT NULL,
  `hashed_password` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `admin_permission` int(11) DEFAULT NULL,
  `comment` varchar(50) NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `shopkeeper`
--

INSERT INTO `shopkeeper` (`shopkeeper_id`, `shopkeeper_name`, `hashed_password`, `admin_permission`, `comment`, `isactive`) VALUES
(1, 'Martin', '*433BE2849BD4D2C882F54E2CFA34E2821CEFB030', 1, 'pass=Martin', 1),
(2, 'Tony', '*B10DCF9BD984B509EAC48AC68B4C2E1EDE585850', 0, 'pass=Tony', 1),
(3, 'Jack', '*B9DF54B251F330BF8F5D0ADBFE7D2C2A02C37788', 0, 'pass=Jack', 1),
(4, 'Mack', '*4CDDFD0B7925FE5DC11AD00917F93CF99D104299', 0, 'pass=Mack', 1),
(5, 'Brian', '*2CC029A4DB70A1632CDF31E1E091AA186B3B3F9F', 0, 'pass=Brian', 1),
(6, 'Russell', '*B76184C5165BE51BA5EC38F9724B9E0C39C7139C', 0, 'pass=Russell', 1);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `subcategory_id` int(11) NOT NULL,
  `subcategory_name` varchar(50) NOT NULL,
  `category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`subcategory_id`, `subcategory_name`, `category_id`) VALUES
(8, 'Drugs', 1),
(9, 'Medicinal Syrup', 1),
(10, 'Medicinal Drops', 1),
(11, 'Medicinal Paste', 1),
(12, 'Supplement', 1),
(13, 'Grocery', 2),
(14, 'Electrolyte Drinks', 3),
(15, 'Snacks', 2),
(16, 'Mineral Water', 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD KEY `invoice_constraint` (`invoice_id`) USING BTREE,
  ADD KEY `cart_ibfk_2` (`product_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`client_id`),
  ADD KEY `client_ibfk_1` (`restriction_id`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoice_id`),
  ADD KEY `invoice_ibfk_1` (`client_id`),
  ADD KEY `invoice_ibfk_2` (`pharmasist_id`),
  ADD KEY `invoice_ibfk_3` (`shopkeeper_id`);

--
-- Indexes for table `pharmasist`
--
ALTER TABLE `pharmasist`
  ADD PRIMARY KEY (`pharmasist_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `product_ibfk_2` (`restriction_id`),
  ADD KEY `product_ibfk_1` (`subcategory_id`);

--
-- Indexes for table `restriction`
--
ALTER TABLE `restriction`
  ADD PRIMARY KEY (`restriction_id`);

--
-- Indexes for table `shopkeeper`
--
ALTER TABLE `shopkeeper`
  ADD PRIMARY KEY (`shopkeeper_id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`subcategory_id`),
  ADD KEY `category_id` (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invoice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `pharmasist`
--
ALTER TABLE `pharmasist`
  MODIFY `pharmasist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `restriction`
--
ALTER TABLE `restriction`
  MODIFY `restriction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `shopkeeper`
--
ALTER TABLE `shopkeeper`
  MODIFY `shopkeeper_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `subcategory_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`invoice_id`) REFERENCES `invoice` (`invoice_id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`);

--
-- Constraints for table `client`
--
ALTER TABLE `client`
  ADD CONSTRAINT `client_ibfk_1` FOREIGN KEY (`restriction_id`) REFERENCES `restriction` (`restriction_id`);

--
-- Constraints for table `invoice`
--
ALTER TABLE `invoice`
  ADD CONSTRAINT `invoice_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`),
  ADD CONSTRAINT `invoice_ibfk_2` FOREIGN KEY (`pharmasist_id`) REFERENCES `pharmasist` (`pharmasist_id`),
  ADD CONSTRAINT `invoice_ibfk_3` FOREIGN KEY (`shopkeeper_id`) REFERENCES `shopkeeper` (`shopkeeper_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`subcategory_id`) REFERENCES `subcategory` (`subcategory_id`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`restriction_id`) REFERENCES `restriction` (`restriction_id`);

--
-- Constraints for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD CONSTRAINT `subcategory_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
